/* main.c - menu-driven 5G reliable packet engine (simulation only).
 * NOTE: this is a software simulation of Go-Back-N reliable delivery. It is
 * NOT a 5G physical layer or a production 5G protocol stack. */
#include <stdio.h>
#include <string.h>
#include "bst.h"
#include "input.h"
#include "sliding_window.h"
#include "storage.h"

#define DATA_FILE   "data/stations.txt"
#define LINE_BUFFER 64U

typedef struct {
    bst_t       tree;
    sw_config_t cfg;
    sw_stats_t  last_stats;
    bool        have_stats;
} app_t;

static status_t validate_name_cb(const char *t) { return station_validate_text(t, STATION_NAME_MAX); }
static status_t validate_type_cb(const char *t) { return station_validate_text(t, STATION_TYPE_MAX); }

static void print_visitor(const station_t *s, void *ctx)
{
    (void)ctx;
    station_print(s);
}

static void report(const char *action, status_t rc)
{
    if (rc == STATUS_OK) {
        (void)printf("%s: success.\n", action);
    } else {
        (void)printf("%s FAILED: %s.\n", action, status_to_string(rc));
    }
}

static status_t prompt_id(const char *label, station_id_t *id)
{
    uint32_t v = 0U;
    status_t rc = input_prompt_u32(stdin, stdout, label, STATION_ID_MIN, STATION_ID_MAX, &v);
    if (rc == STATUS_OK) { *id = v; }
    return rc;
}

/* Prompts for every editable field: name, distance, fare, platform, type. */
static status_t prompt_body(char *name, char *type, uint32_t *dist,
                            uint32_t *fare, uint32_t *platform)
{
    status_t rc = input_prompt_text(stdin, stdout, "Station name", name, LINE_BUFFER, validate_name_cb);

    if (rc == STATUS_OK) {
        rc = input_prompt_u32(stdin, stdout, "Distance (km)", 0U, STATION_DISTANCE_MAX, dist);
    }
    if (rc == STATUS_OK) {
        rc = input_prompt_u32(stdin, stdout, "Fare", 0U, STATION_FARE_MAX, fare);
    }
    if (rc == STATUS_OK) {
        rc = input_prompt_u32(stdin, stdout, "Platform number", STATION_PLATFORM_MIN,
                              STATION_PLATFORM_MAX, platform);
    }
    if (rc == STATUS_OK) {
        rc = input_prompt_text(stdin, stdout, "Station type (e.g. gNodeB, Core)", type, LINE_BUFFER, validate_type_cb);
    }
    return rc;
}

static status_t do_add(app_t *a)
{
    station_id_t id = 0U;
    char name[LINE_BUFFER];
    char type[LINE_BUFFER];
    uint32_t dist = 0U;
    uint32_t fare = 0U;
    uint32_t platform = 0U;
    station_t s;
    status_t rc;

    rc = prompt_id("Station ID", &id);
    if (rc == STATUS_OK) { rc = prompt_body(name, type, &dist, &fare, &platform); }
    if (rc == STATUS_OK) { rc = station_init(&s, id, name, dist, fare, platform, type); }
    if (rc == STATUS_OK) { rc = bst_insert(&a->tree, &s); }
    if (rc != STATUS_ERR_IO) { report("Add station", rc); }
    return rc;
}

static status_t do_search(app_t *a)
{
    station_id_t id = 0U;
    status_t rc = prompt_id("Station ID to search", &id);

    if (rc == STATUS_OK) {
        const station_t *found = bst_search(&a->tree, id);

        if (found == NULL) {
            (void)printf("Station %u not found.\n", (unsigned)id);
        } else {
            station_print(found);
        }
    } else if (rc != STATUS_ERR_IO) {
        report("Search", rc);
    } else {
        /* end of input: reported by the caller */
    }
    return rc;
}

/* Update replaces name, distance, fare, platform and type of an existing station. */
static status_t do_update(app_t *a)
{
    station_id_t id = 0U;
    char name[LINE_BUFFER];
    char type[LINE_BUFFER];
    uint32_t dist = 0U;
    uint32_t fare = 0U;
    uint32_t platform = 0U;
    status_t rc = prompt_id("Station ID to update", &id);

    if ((rc == STATUS_OK) && (bst_search(&a->tree, id) == NULL)) {
        (void)printf("Station %u not found.\n", (unsigned)id);
    } else {
        if (rc == STATUS_OK) { rc = prompt_body(name, type, &dist, &fare, &platform); }
        if (rc == STATUS_OK) { rc = bst_update(&a->tree, id, name, dist, fare, platform, type); }
        if (rc != STATUS_ERR_IO) { report("Update station", rc); }
    }
    return rc;
}

static status_t do_delete(app_t *a)
{
    station_id_t id = 0U; status_t rc = prompt_id("Station ID to delete", &id);
    if (rc == STATUS_OK) { rc = bst_delete(&a->tree, id); }
    if (rc != STATUS_ERR_IO) { report("Delete station", rc); }
    return rc;
}

static void do_display(const app_t *a)
{
    if (a->tree.root == NULL) {
        (void)printf("No stations stored.\n");
    } else {
        (void)printf("  %-6s %-31s %10s  %7s  %8s  %s\n", "ID", "Name", "Distance",
                     "Fare", "Platform", "Type");
        (void)bst_inorder(&a->tree, print_visitor, NULL);
    }
}

static void do_stats(const app_t *a)
{
    uint32_t count = 0U; station_id_t mn = 0U; station_id_t mx = 0U;
    if (bst_stats(&a->tree, &count, &mn, &mx) == STATUS_ERR_EMPTY) {
        (void)printf("No stations stored (total 0).\n");
    } else {
        (void)printf("Total stations: %u | Min ID: %u | Max ID: %u\n",
                     (unsigned)count, (unsigned)mn, (unsigned)mx);
    }
}

static status_t do_transmit(app_t *a)
{
    station_id_t src = 0U;
    station_id_t dst = 0U;
    station_id_t bad = 0U;
    status_t rc;

    rc = prompt_id("Source Station ID", &src);
    if (rc == STATUS_OK) { rc = prompt_id("Destination Station ID", &dst); }
    if (rc != STATUS_OK) {
        if (rc != STATUS_ERR_IO) { report("Transmission", rc); }
    } else {
        status_t vrc = station_validate_endpoints(&a->tree, src, dst, &bad);

        if (vrc != STATUS_OK) {
            (void)printf("Validation failed (station %u): %s. Transmission not started.\n",
                         (unsigned)bad, status_to_string(vrc));
        } else {
            (void)printf("\n--- Go-Back-N transmission: station %u -> %u ---\n", (unsigned)src, (unsigned)dst);
            rc = sw_simulate(&a->cfg, src, dst, stdout, &a->last_stats);
            a->have_stats = true;
            (void)printf("--- Final status: %s ---\n", (rc == STATUS_OK) ? "ALL PACKETS DELIVERED" : status_to_string(rc));
            sw_print_stats(stdout, &a->last_stats);
            rc = STATUS_OK;
        }
    }
    return rc;
}

static status_t ask_u32(const char *label, uint32_t lo, uint32_t hi, uint32_t *v)
{
    status_t rc = input_prompt_u32(stdin, stdout, label, lo, hi, v);
    if ((rc != STATUS_OK) && (rc != STATUS_ERR_IO)) {
        (void)printf("Configuration unchanged.\n");
    }
    return rc;
}

static status_t do_config(app_t *a)
{
    sw_config_t c = a->cfg;
    uint32_t w = 0U;
    uint32_t dl = 0U;
    uint32_t al = 0U;
    uint32_t dp = 0U;
    uint32_t ap = 0U;
    uint32_t mr = 0U;
    status_t rc;

    rc = ask_u32("Sender window size", 1U, SW_WINDOW_MAX, &w);
    if (rc == STATUS_OK) { rc = ask_u32("Packet count", 1U, SW_MAX_PACKETS, &c.packet_count); }
    if (rc == STATUS_OK) { rc = ask_u32("Timeout (ticks)", 1U, 100U, &c.timeout_ticks); }
    if (rc == STATUS_OK) { rc = ask_u32("Max retries per packet", 1U, 20U, &mr); }
    if (rc == STATUS_OK) { rc = ask_u32("Drop every Nth data packet (0=off)", 0U, 1000U, &dl); }
    if (rc == STATUS_OK) { rc = ask_u32("Drop every Nth ACK (0=off)", 0U, 1000U, &al); }
    if (rc == STATUS_OK) { rc = ask_u32("Random data loss %", 0U, 100U, &dp); }
    if (rc == STATUS_OK) { rc = ask_u32("Random ACK loss %", 0U, 100U, &ap); }
    if (rc == STATUS_OK) { rc = ask_u32("Random seed", 0U, 1000000U, &c.seed); }
    if (rc == STATUS_OK) {
        c.window_size = (uint8_t)w;          /* ranges already enforced above */
        c.max_retries = (uint8_t)mr;
        c.data_loss_every = dl;
        c.ack_loss_every = al;
        c.data_loss_percent = (uint8_t)dp;
        c.ack_loss_percent = (uint8_t)ap;
        rc = sw_config_validate(&c);
        if (rc == STATUS_OK) { a->cfg = c; }
        report("Configure sliding window", rc);
        rc = STATUS_OK;
    }
    return rc;
}

static void do_show_stats(const app_t *a)
{
    if (!a->have_stats) {
        (void)printf("No transmission has been run yet.\n");
    } else {
        sw_print_stats(stdout, &a->last_stats);
    }
}

static void print_menu(void)
{
    (void)printf("\n===== 5G Reliable Packet Engine (Go-Back-N simulation) =====\n"
                 " 1 Add station            7 Simulate transmission\n"
                 " 2 Search station         8 Configure sliding window\n"
                 " 3 Update station         9 Show transmission statistics\n"
                 " 4 Delete station        10 Save stations (" DATA_FILE ")\n"
                 " 5 List stations (sorted) 11 Load stations\n"
                 " 6 Station statistics    12 Exit\n");
}

int main(void)
{
    app_t app;
    bool running = true;

    bst_init(&app.tree);
    (void)sw_config_default(&app.cfg);
    (void)memset(&app.last_stats, 0, sizeof(app.last_stats));
    app.have_stats = false;

    while (running) {
        uint32_t choice = 0U;
        status_t rc;

        print_menu();
        rc = input_prompt_u32(stdin, stdout, "Choice", 1U, 12U, &choice);
        if (rc == STATUS_OK) {
            switch (choice) {
            case 1:  rc = do_add(&app); break;
            case 2:  rc = do_search(&app); break;
            case 3:  rc = do_update(&app); break;
            case 4:  rc = do_delete(&app); break;
            case 5:  do_display(&app); break;
            case 6:  do_stats(&app); break;
            case 7:  rc = do_transmit(&app); break;
            case 8:  rc = do_config(&app); break;
            case 9:  do_show_stats(&app); break;
            case 10: report("Save", storage_save(&app.tree, DATA_FILE)); break;
            case 11: report("Load", storage_load(&app.tree, DATA_FILE)); break;
            default: running = false; break;
            }
        }
        if (rc == STATUS_ERR_IO) {           /* end of input */
            running = false;
        }
    }
    bst_destroy(&app.tree);                    /* free every node */
    (void)printf("Goodbye.\n");
    return 0;
}
