# Coverage Report (measured in this workspace)

Command: `make coverage` using GCC/gcov with `-O0 --coverage`. Counts cover `src/*.c` library modules only; the interactive `src/main.c` menu is excluded because it is not linked into the unit-test binaries.

| File | Lines % | Branch % | Function % |
|---|---:|---:|---:|
| `src/common.c` | 100.00 | 100.00 | 100.0 (1/1) |
| `src/bst.c` | 97.83 | 89.22 | 100.0 (10/10) |
| `src/station.c` | 100.00 | 100.00 | 100.0 (8/8) |
| `src/packet.c` | 100.00 | 89.06 | 100.0 (11/11) |
| `src/sliding_window.c` | 98.09 | 85.34 | 100.0 (22/22) |
| `src/storage.c` | 94.17 | 89.77 | 100.0 (6/6) |
| `src/input.c` | 100.00 | 85.58 | 100.0 (4/4) |
| **TOTAL** | **98.2** | **89.1** | **100.0** |

These values are generated from the current test suite in this workspace. They are not a claim of full application/menu coverage. Uncovered lines and branch outcomes are mainly defensive I/O/allocation/error paths.

Reproduce: `make coverage`. For annotated output: `gcov -b -o build/cov src/packet.c`.
