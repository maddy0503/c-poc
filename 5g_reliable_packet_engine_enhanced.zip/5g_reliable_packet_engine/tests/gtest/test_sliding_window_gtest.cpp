// GoogleTest unit + functional tests for the Go-Back-N engine.
#include <gtest/gtest.h>

extern "C" {
#include "packet.h"
#include "sliding_window.h"
}

namespace {

sw_config_t make_cfg()
{
    sw_config_t c;
    EXPECT_EQ(STATUS_OK, sw_config_default(&c));
    c.data_loss_every = 0U;
    c.ack_loss_every = 0U;
    c.data_loss_percent = 0U;
    c.ack_loss_percent = 0U;
    return c;
}

TEST(SequenceArithmetic, WrapAround)
{
    EXPECT_EQ(0U, seq_next(15U));
    EXPECT_EQ(1U, seq_next(0U));
    EXPECT_EQ(3U, seq_distance(14U, 1U));
    EXPECT_EQ(0U, seq_distance(5U, 5U));
}

TEST(ChannelQueue, FifoAndDueTick)
{
    pkt_queue_t q;
    pktq_init(&q);
    packet_t p, out;
    const uint8_t data[2] = {1U, 2U};
    ASSERT_EQ(STATUS_OK, packet_init(&p, 3U, 1U, 2U, data, sizeof data));
    ASSERT_EQ(STATUS_OK, pktq_push(&q, &p, 5U));
    EXPECT_FALSE(pktq_pop_due(&q, 4U, &out));
    ASSERT_TRUE(pktq_pop_due(&q, 5U, &out));
    EXPECT_EQ(3U, out.seq);
    EXPECT_FALSE(pktq_pop_due(&q, 100U, &out));
}

TEST(ChannelQueue, FullQueueReportsError)
{
    pkt_queue_t q;
    pktq_init(&q);
    packet_t p;
    ASSERT_EQ(STATUS_OK, packet_init(&p, 0U, 1U, 2U, nullptr, 0U));
    for (size_t i = 0; i < CHANNEL_CAP; ++i) {
        ASSERT_EQ(STATUS_OK, pktq_push(&q, &p, 0U));
    }
    EXPECT_EQ(STATUS_ERR_FULL, pktq_push(&q, &p, 0U));
}

TEST(Config, ValidationRanges)
{
    sw_config_t c = make_cfg();
    EXPECT_EQ(STATUS_OK, sw_config_validate(&c));
    c.window_size = 0U;
    EXPECT_EQ(STATUS_ERR_RANGE, sw_config_validate(&c));
    c.window_size = 16U;
    EXPECT_EQ(STATUS_ERR_RANGE, sw_config_validate(&c));
    c = make_cfg();
    c.packet_count = 0U;
    EXPECT_EQ(STATUS_ERR_RANGE, sw_config_validate(&c));
}

TEST(Receiver, AcceptsInOrderDiscardsOthers)
{
    sw_receiver_t r;
    ASSERT_EQ(STATUS_OK, sw_receiver_init(&r, 4U));
    packet_t p;
    ack_t ack;
    rx_result_t res;

    ASSERT_EQ(STATUS_OK, packet_init(&p, 0U, 1U, 2U, nullptr, 0U));
    ASSERT_EQ(STATUS_OK, sw_receiver_on_packet(&r, &p, &ack, &res));
    EXPECT_EQ(RX_ACCEPTED, res);
    EXPECT_EQ(1U, ack.ack_seq);

    ASSERT_EQ(STATUS_OK, packet_init(&p, 3U, 1U, 2U, nullptr, 0U));  // gap
    ASSERT_EQ(STATUS_OK, sw_receiver_on_packet(&r, &p, &ack, &res));
    EXPECT_EQ(RX_OUT_OF_ORDER, res);
    EXPECT_EQ(1U, ack.ack_seq);  // same cumulative ACK

    ASSERT_EQ(STATUS_OK, packet_init(&p, 0U, 1U, 2U, nullptr, 0U));  // old one again
    ASSERT_EQ(STATUS_OK, sw_receiver_on_packet(&r, &p, &ack, &res));
    EXPECT_EQ(RX_DUPLICATE, res);
}

TEST(Sender, WindowLimitsOutstandingPackets)
{
    sw_sender_t s;
    ASSERT_EQ(STATUS_OK, sw_sender_init(&s, 3U, 10U, 1U, 2U));
    packet_t *p = nullptr;
    for (int i = 0; i < 3; ++i) {
        ASSERT_TRUE(sw_sender_can_send(&s));
        ASSERT_EQ(STATUS_OK, sw_sender_next_packet(&s, nullptr, 0U, 0U, &p));
    }
    EXPECT_FALSE(sw_sender_can_send(&s));
    EXPECT_EQ(3U, sw_sender_outstanding(&s));

    uint32_t adv = 0U;
    ASSERT_EQ(STATUS_OK, sw_sender_process_ack(&s, 2U, 1U, &adv));
    EXPECT_EQ(2U, adv);
    EXPECT_TRUE(sw_sender_can_send(&s));
    ASSERT_EQ(STATUS_OK, sw_sender_process_ack(&s, 2U, 2U, &adv));  // duplicate ACK
    EXPECT_EQ(0U, adv);
}

TEST(Simulation, NoLossDeliversEverythingWithoutRetransmission)
{
    sw_config_t c = make_cfg();
    c.window_size = 3U;
    c.packet_count = 20U;
    sw_stats_t st;
    ASSERT_EQ(STATUS_OK, sw_simulate(&c, 1U, 2U, nullptr, &st));
    EXPECT_EQ(20U, st.delivered);
    EXPECT_EQ(20U, st.data_tx);
    EXPECT_EQ(0U, st.retransmissions);
}

TEST(Simulation, RecoversFromDataLoss)
{
    sw_config_t c = make_cfg();
    c.packet_count = 12U;
    c.data_loss_every = 3U;
    sw_stats_t st;
    ASSERT_EQ(STATUS_OK, sw_simulate(&c, 1U, 2U, nullptr, &st));
    EXPECT_EQ(12U, st.delivered);
    EXPECT_GT(st.retransmissions, 0U);
    EXPECT_GT(st.timeouts, 0U);
}

TEST(Simulation, RecoversFromAckLoss)
{
    sw_config_t c = make_cfg();
    c.window_size = 1U;
    c.packet_count = 10U;
    c.ack_loss_every = 2U;
    sw_stats_t st;
    ASSERT_EQ(STATUS_OK, sw_simulate(&c, 1U, 2U, nullptr, &st));
    EXPECT_EQ(10U, st.delivered);
    EXPECT_GT(st.duplicates, 0U);
}

TEST(Simulation, GivesUpAfterMaxRetries)
{
    sw_config_t c = make_cfg();
    c.packet_count = 5U;
    c.data_loss_every = 1U;
    c.max_retries = 3U;
    sw_stats_t st;
    EXPECT_EQ(STATUS_ERR_MAX_RETRIES, sw_simulate(&c, 1U, 2U, nullptr, &st));
}

TEST(Simulation, SequenceNumbersWrapManyTimes)
{
    sw_config_t c = make_cfg();
    c.window_size = SW_WINDOW_MAX;
    c.packet_count = 100U;
    sw_stats_t st;
    ASSERT_EQ(STATUS_OK, sw_simulate(&c, 1U, 2U, nullptr, &st));
    EXPECT_EQ(100U, st.delivered);
}

TEST(Simulation, RandomLossIsRepeatableForSameSeed)
{
    sw_config_t c = make_cfg();
    c.packet_count = 50U;
    c.data_loss_percent = 20U;
    c.ack_loss_percent = 10U;
    c.seed = 1234U;
    sw_stats_t a, b;
    sw_simulate(&c, 1U, 2U, nullptr, &a);
    sw_simulate(&c, 1U, 2U, nullptr, &b);
    EXPECT_EQ(a.data_tx, b.data_tx);
    EXPECT_EQ(a.ticks, b.ticks);
    EXPECT_EQ(a.delivered, b.delivered);
}

TEST(PacketIntegrity, CorruptedPayloadIsRejected)
{
    packet_t packet{};
    ack_t ack{};
    sw_receiver_t receiver{};
    rx_result_t result = RX_ACCEPTED;
    const uint8_t payload[] = {1U, 2U, 3U};
    ASSERT_EQ(STATUS_OK, packet_init(&packet, 0U, 101U, 202U, payload, sizeof(payload)));
    ASSERT_TRUE(packet_verify(&packet));
    ASSERT_EQ(STATUS_OK, sw_receiver_init(&receiver, 4U));
    packet.payload[0] ^= 0x80U;
    EXPECT_FALSE(packet_verify(&packet));
    EXPECT_EQ(STATUS_ERR_FORMAT, sw_receiver_on_packet(&receiver, &packet, &ack, &result));
    EXPECT_EQ(0U, receiver.delivered);
}

}  // namespace
