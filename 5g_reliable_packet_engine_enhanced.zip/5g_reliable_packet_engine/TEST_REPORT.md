# Test Report

Executed on Ubuntu 24.04, GCC 13.3.0, `make test` (flags: -std=c11 -O2 -Wall -Wextra -Wpedantic -Wconversion -Wshadow).

| Suite | Checks | Failed |
|---|---|---|
| test_bst | 92 | 0 |
| test_station | 122 | 0 |
| test_sliding_window | 598 | 0 |

All 45 test functions passed (station fare/platform tests included). Also run clean under AddressSanitizer + UBSan (`make sanitize`); valgrind was not available.

## GoogleTest suites (`make gtest`)
31 tests in `tests/gtest/` (BST 9, station+input+storage 8, sliding window 12, threads 2). They passed against the
code here using a minimal stand-in for `gtest.h`; run `make gtest` once with the real GoogleTest library to confirm on your machine.

## Raw result lines
```
[PASS] test_insert_empty
[PASS] test_insert_multiple_and_inorder_sorted
[PASS] test_duplicate_rejected
[PASS] test_search
[PASS] test_update
[PASS] test_delete_leaf
[PASS] test_delete_one_child
[PASS] test_delete_two_children
[PASS] test_delete_root
[PASS] test_delete_successor_is_direct_right_child
[PASS] test_stats_and_empty
[PASS] test_empty_tree_operations
[PASS] test_preorder_order
[PASS] test_invalid_input
[PASS] test_capacity_limit
98 checks, 0 failed
[PASS] test_station_validation
[PASS] test_endpoint_validation
[PASS] test_parse_u32
[PASS] test_read_line
[PASS] test_prompts
[PASS] test_save_and_load_roundtrip
[PASS] test_load_rejects_bad_files
[PASS] test_save_errors
[PASS] test_sample_data_file_and_functional_flow
[PASS] test_status_strings
146 checks, 0 failed
[PASS] test_config_validation
[PASS] test_invalid_packet_count_and_window_in_simulation
[PASS] test_fewer_than_window
[PASS] test_exactly_window
[PASS] test_more_than_window_no_loss
[PASS] test_flow_control_sender_window
[PASS] test_sender_exhausted_and_init_errors
[PASS] test_receiver_in_order_and_advance_and_wraparound
[PASS] test_receiver_duplicate_and_out_of_order
[PASS] test_timeout_and_retransmit_marking
[PASS] test_packet_loss_recovery
[PASS] test_ack_loss_and_duplicate_detection
[PASS] test_out_of_order_discarded_in_simulation
[PASS] test_max_retransmission_limit
[PASS] test_sequence_wraparound_in_simulation
[PASS] test_random_loss_is_repeatable
[PASS] test_logging_and_stats_output
[PASS] test_packet_and_queue_primitives
[PASS] test_transmission_statistics_consistency
598 checks, 0 failed
```

## Notable cases (expected → actual: all matched)
| Test | Expected |
|---|---|
| delete leaf / one child / two children / root | node removed, inorder still sorted, count decremented |
| duplicate Station ID | `STATUS_ERR_DUPLICATE`, count unchanged |
| empty-tree stats | `STATUS_ERR_EMPTY`, min=max=0 |
| window 3, 20 packets, no loss | 20 tx, 0 retransmissions, delivered 20 |
| `data_loss_every=3` | all 12 delivered, retransmissions > 0, timeouts > 0 |
| window 1 + `ack_loss_every=2` | all delivered, duplicates detected at receiver |
| `data_loss_every=1`, `max_retries=3` | `STATUS_ERR_MAX_RETRIES`, 4 timeouts, terminates |
| window 15, 100 packets (many wraps) | delivered 100, tx 100 |
| packet count 0 / window 0 or 16 | `STATUS_ERR_RANGE` |
| numeric input `""`, `-5`, `abc`, `12abc`, overflow | rejected without crash |
| corrupt station files (bad header, dup id, bad fields, long line) | load fails, original tree untouched |
