# Static and Dynamic Analysis Status

Status below reflects the tools actually available in the packaging environment. Do not interpret unavailable tools as passing.

| Tool | Command | Result in this workspace |
|---|---|---|
| GCC warning build | `make -B` | PASS; no compiler warnings observed |
| C unit tests | `make test` | PASS; 48 test functions, 863 checks, 0 failures |
| AddressSanitizer + UBSan | `make sanitize` | PASS; all three C test binaries clean |
| gcov coverage | `make coverage` | PASS; 98.2% line, 89.1% branch, 100% function coverage for `src/*.c` library modules |
| Cppcheck | `make cppcheck` | NOT RUN; cppcheck is not installed in this environment. Target now exits with an installation hint. |
| Valgrind Memcheck | `make valgrind` | NOT RUN; valgrind is not installed in this environment. Linux/WSL only. |
| Helgrind | `make helgrind` | NOT RUN; requires Valgrind and GoogleTest, which are unavailable here. |
| GoogleTest | `make gtest` | NOT RUN; GoogleTest headers/library are not installed here. A corruption-detection GTest case has been added. |
| MISRA C:2012 addon | `make misra` | NOT RUN; requires Cppcheck; rule descriptions require a separately licensed MISRA rule-text file. |
| ThreadSanitizer | `make tsan` | NOT RUN in this run; may depend on host/runtime support. |

## Run on Ubuntu / Debian

```sh
sudo apt update
sudo apt install build-essential cppcheck valgrind libgtest-dev
make clean
make test
make gtest
make cppcheck
make sanitize
make valgrind
make helgrind
make coverage
```

MISRA addon (optional; licensed rule text is not included):

```sh
make misra MISRA_RULES=/path/to/misra_c_2012_rules.txt
```

`make quality` runs the combined gate and will stop when a required tool is missing or a check fails. Cppcheck suppressions are in `config/cppcheck_suppressions.txt`; keep suppressions minimal and documented.

## Packet integrity feature

Packets now include a 16-bit Fletcher-style checksum computed over sequence number, source/destination IDs, payload length, and payload bytes. The receiver validates the checksum before delivery and rejects a corrupted packet with `STATUS_ERR_FORMAT`. This is an accidental-corruption detector, not cryptographic authentication.
